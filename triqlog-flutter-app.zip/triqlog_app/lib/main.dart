import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dashboard.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(const TriqLogApp());
}

class TriqLogApp extends StatelessWidget {
  const TriqLogApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TriqLog — Driver',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFF09090F),
        colorScheme: ColorScheme.dark(
          primary:    const Color(0xFFF0B429),
          secondary:  const Color(0xFF22C55E),
          surface:    const Color(0xFF181B28),
          background: const Color(0xFF09090F),
        ),
        fontFamily: 'Outfit',
      ),
      home: const DriverDashboard(),
    );
  }
}
